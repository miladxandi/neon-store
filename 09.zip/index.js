// let jObject = {
//     "name" : "Milad",
//     "lastname" : "Xandi",
//     "national_number" : "001859674",
//     "nationality" : "IR",
//     "sub_persons":[
//         {
//             "name" : "Mamad",
//             "lastname" : "Xandi",
//             "national_number" : "001859687",
//             "nationality" : "IR",
//         },
//         {
//             "name" : "Reza",
//             "lastname" : "Xandi",
//             "national_number" : "001859688",
//             "nationality" : "IR",
//         },
//     ]
// }
//
// let arr = [5,7,9,11,13,15,17,19]
//
// console.log(arr[0])


async function fetchProducts() {
    let response = await axios.get("https://api.escuelajs.co/api/v1/products");
    return response.data;
}

const productCard = document.querySelector("#card")
const basketItem = document.querySelector("#item")
const productImage = document.querySelector("#product-image")

const holder = document.querySelector("#cards-holder")
const basketCard = document.querySelector("#cart")


let products = await fetchProducts();

console.log(products)

function refreshBasket(){
    let addedItems = JSON.parse(localStorage.getItem("products"));
    basketCard.innerHTML = "";
    addedItems.forEach((product, productIndex) => {
        var item = basketItem.cloneNode(true);
        item.classList.remove('d-none');
        item.querySelector('.header').innerHTML = product.title;
        item.querySelector('.description').innerHTML = 1;
        item.querySelector('.extra').innerHTML = "$"+product.price;
        basketCard.appendChild(item);
    })
}

products.forEach((product, productIndex) => {
    var currentProductHtml = productCard.cloneNode(true);
    currentProductHtml.classList.remove('d-none');
    currentProductHtml.id = product.id;

    product.images.forEach((image, index) => {
        var currentImage = productImage.cloneNode(true);
        currentImage.classList.remove('d-none');
        currentImage.src = image;
        currentImage.id = product.id+'-'+index;

        if (index===0){
            currentImage.classList.remove('hidden');
            currentImage.classList.add('visible');
        }

        currentProductHtml.querySelector("div").appendChild(currentImage);
    })

    currentProductHtml.querySelector('button').addEventListener('click', (e) => {
        console.log('clicked on element '+productIndex+" which is for "+product.title);
        let addedProducts = JSON.parse(localStorage.getItem("products"));

        if(addedProducts.length === undefined || addedProducts.length === 0){
            addedProducts=[products[productIndex]];
        }else{
            addedProducts.push(products[productIndex]);
        }
        localStorage.setItem("products", JSON.stringify(addedProducts));
        refreshBasket();
    })


    currentProductHtml.querySelector('.product-title').innerHTML = product.title;
    currentProductHtml.querySelector('.product-description').innerHTML = product.description.substring(0, 50)+"...";
    currentProductHtml.querySelector('.product-price').innerHTML = product.price +"$";
    holder.appendChild(currentProductHtml);
})


refreshBasket();
